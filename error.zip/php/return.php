<?php


$id =1;
echo gettype($id); ?>