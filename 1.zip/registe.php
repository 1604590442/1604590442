<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="registe.css" type="text/css" />
<?php
    $db_loc="localhost";
    $db_usr="root";
    $db_pwd="root";
    
    //mysqli_query($link,"update users set pwd = 123 where id = 3;");//写到这里可以
?>
<title>123</title>
<meta charset="utf-8"/>
</head>
<script>
    function registe()
    {
        var user=document.getElementById("user");
        var pwd=document.getElementById("pwd");
        <?php
        $link=mysqli_connect($db_loc,$db_usr,$db_pwd,"http://s38y129818_wicp_vip",3306);
        if(!$link)
        echo "数据库连接失败";
        mysqli_query($link,"update users set user ="+ /*user*/ +" where id = 3;");//写到这里不知道为什么不行（要先写$link）
        ?>
        alert(user.value);
    }
</script>
<body>
    <div class="registe">
            <h2 style="color:blue; text-align:center">测试注册界面<br /></h2>
            <div class="registe1">
                <input type="text" maxlength="11" style="height:40px;width:240px;" value="" placeholder="请输入用户名" id="user" />
            </div>
            <div class="registe1">
                <input type="password" maxlength="16" style="height:40px;width:240px;" value="" placeholder="请输入密码" id="pwd"/>
            </div>
            <br>
            <input type="button" value="注册" style="width:70px;height:40px; margin: 10px 90px 0px 335px;" onclick="registe()" >
        </div>
</body>
</html>