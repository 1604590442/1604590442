<?php
    echo "<script>alert(\"你™不登录就想黑我是吧\");</script>";
    sleep(1);
    echo "<meta http-equiv='Refresh' content='0;URL=index.php'>";//跳转有弹窗
    //header("location:index.php"); // 跳转没有弹窗
?>