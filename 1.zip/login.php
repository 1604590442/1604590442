
<?php
    include "/phpstudy_pro/WWW/s38y129818.wicp.vip/connect.php";
    $name = $_POST['name'];
    $pwd = $_POST['pwd'];
    $name =trim($name);
    $pwd = trim($pwd);
    $rep =base64_encode("false");
    $con=mysqli_connect("localhost",$username,$password,$database,$port);
    //echo $name;
    //echo $pwd;
    $sql ="select name,pwd from admin where name='".$name."' and pwd='".$pwd."'";
    @$result=mysqli_query($con,$sql);
    $arr= mysqli_fetch_all($result);
    //var_dump($arr);
    $login = base64_encode("yes");
    if($arr != null)
        header('Location:1.php');
    else{
        header("Location:index.php?value=".$rep);
    }
    mysqli_close($con);
?>