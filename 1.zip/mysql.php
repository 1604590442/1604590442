<?php
$db_host="localhost";
$db_user="root";//账号
$db_psw="root";//密码

$link=mysqli_connect($db_host,$db_user,$db_psw);
if(!$link){
    echo"fail";
}//确认是否获成功

mysqli_set_charset($link,"utf8");//设置字符集
mysqli_select_db($link, "admin");//选择数据库
$sql="SELECT*FROM `user`.`admin`";//写入数据（注意``）
$request=mysqli_query($link,$sql);//发送sql语句

if (!$request) {
    printf("Error: %s\n", mysqli_error($link));
    exit();
}//显示错误

while($request_arr=mysqli_fetch_assoc($request)){
    echo"<pre>";
    print_r($request_arr);
}//打印数据库内容

mysqli_close($link);//关闭