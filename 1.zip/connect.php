<?php
    $username="root";
    $password="root";
    $database="user";
    $port="3306";
?>