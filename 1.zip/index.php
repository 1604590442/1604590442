<!DOCTYPE html>
<html>
<head>
    <title>我的小垃圾</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="text.css" type="text/css" />
    <!--引入css-->
    <script src="myscript.js"></script>
</head>
<body id="top0"style="background: url(<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'/../img/2.jpg');?>);">
    <h2 style="color:forestgreen; text-align:center">不知道取什么名字好</h2>
    <h4 id="time" style="float:right; color:greenyellow">
    <button type="button" onclick="time()" style="color:white;float:right; background:none;">点击显示时间</button>
    </h4>
	<h4 id="change" style="float:left; color:greenyellow">
	<button type="button" onclick="change()">123 </button>
    </h4>
    <br /><br /><br /><br />
    <table border="0">
        <tr>
            <th style="width:355px;height:40px;"><a href="1.html">笔记</a></th>
            <th style="width:355px;height:40px;"><a href="1.html">学习</a></th>
            <th style="width:355px;height:40px;"><a href="1.html">玩乐</a></th>
            <th style="width:355px;height:40px;"><a href="1.html">还没想好</a></th>
        </tr>
    </table>

    <div class="top">
        <div class="top1" style="background: url(<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'/../img/1.jpg');?>);">
            <!--a href="/img/3.jpg" download="/img/3.jpg" title="下载背景图"  ><img src="/img/3.jpg"style="width:100%;height:500px;"></a-->
            <a target="_blank" href=" https://share.weiyun.com/wDdYmRNE" class="text-style" style="color:blue;">靶场<br></a>
            <a target="_blank" href=" https://share.weiyun.com/F7RBR7UD" class="text-style" style="color:green; ">时间深渊<br></a>
            <a target="_blank" href="https://share.weiyun.com/NoZjiMJn " class="text-style" style="color:darkmagenta;">There_Is_No_Game_Wrong_Dimension.CHS.Green<br></a>
            <a target="_blank" href="https://share.weiyun.com/qROVQaEs" class="text-style" style="color:aquamarine; ">书籍<br></a>
            <a target="_blank" href="https://share.weiyun.com/eDQBRtE2" class="text-style" style="color:black;">网络基础课程文件（仅供参考)<br></a>
			<a target="_blank" href="registe.php" class="text-style" style="color:blue;">注册<br></a>
            <!-- <table class="">
            表格
            </table>-->
            <!--a target="_blank" href="/img/1.jpg" download="/img/1.jpg" style="color:black;position:fixed;right:0px;bottom:0px;">
                <script>
                    document.onclick(alert("下载成功！"));
                </script>
            下载背景图
            </!--a-->
        </div>
        <div class="top2" style="background-color:white;">
            <h2 style="color:blue; text-align:center">测试登录界面<br /></h2>
            <!--div class="login" style="margin:100px 200px 0px auto;">
                <img style="margin-left:-100px;margin-bottom:-10px;" width="50" height="40" src="/img/user.jpg" />
                <input type="text" maxlength="11" style="height:40px;width:240px;" placeholder="请输入用户名" />
            </div>
            <div class="login" style="margin:5px 200px 0px auto;">
                <img style="margin-left:-100px;margin-bottom:-10px;" width="50" height="40" src="/img/psw.jpg" />
                <input type="password" maxlength="16" style="height:40px;width:240px;" placeholder="请输入密码" />
            </div-->
            <br/>
            <div style="margin:10% auto auto 40%; ">
                <form method="post" action="login.php" > <!--action="<--?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" -->
                    <input type="text" placeholder="账号" name="name"/><br/>
                    <input type="password" placeholder="密码"  name="pwd"/><br/>
                    <input type="submit" value="提交" style="margin: 10px auto auto 55px;"/>
                </form>
                <?php
                    $a=$_GET["value"];
                    //echo htmlspecialchars($_SERVER["PHP_SELF"]);
                    if(base64_decode($a)=="false")
                    {
                        echo "<script>alert(\"密码错误\");</script>";
                        sleep(1);
                        echo "<meta http-equiv='Refresh' content='0;URL=index.php'>";//跳转有弹窗
                        //header("location:index.php"); // 跳转没有弹窗
                    }
                ?>
            </div>
        </div>
    </div>
    
    <br /><br /><br />
    <!--img width="533" height="620" src="/img/"/-->
    <div style="width:80px;height:80px;float:right; ">
        <a href="#top0" style=" background:none;"><img src="<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'/../img/top.jpg');?>" style="background-color:none; width:80px;height:80px;" /></a>
    </div>
</body>
</html>