function time() {
    document.getElementById("time").innerHTML = Date();
}
function change() {
    var x = radom(0, 10);
    document.getElementById("change").alert = alert("x");
    
}