<?php
include "connect.php";
$con = mysqli_connect("localhost", $username, $password, "information_schema", $port);
$onepage = 30;
?>
<style>
    * {
        margin: 0;
        padding: 0;
    }

    table {
        position: relative;
        left: 10%;
        border: 1px 1px 0 auto;
        border-color: black;
    }

    button {
        display: block;
        position: relative;
        background-color: white;
        border: none;
        width: 99px;
        height: 40px;
        left: 80%;

    }

    body {
         min-width: none;
        /* max-width: 2000px; */
    }

    form {
         float:right; 
         position: relative;
         right: 10%;
    }
</style>
<table style="width:80%;color:red;text-align:center;" border=1px;  cellspacing="0"><!--align="center"-->
    <tbody>
        <tr>
            <th>ID</th>
            <th>账号</th>
            <th>密码</th>
        </tr>
        <?php
        if (isset($_GET['page'])) {
            if(is_int($_GET['id'])==false)//?????????
                $page = $_GET['page'];
        } else
            $page = 0;
        //echo $page;
        @$page = $page * $onepage;
        //$page = $_POST[''];
        //$cmd = "select * from admin limit $page,$onepage";
        $cmd = "select * from tables limit $page,$onepage";
        $request = mysqli_query($con, $cmd);
        $arr = mysqli_fetch_all($request);
        //var_dump($arr);
        mysqli_close($con);
        for ($i = 0; $i < $onepage; $i++) {
            echo "<tr>\n<td>" . $arr[$i][0] . " </td>\n<td> " . $arr[$i][1] . "</td>\n<td> " . $arr[$i][2] . "</td>\n</tr>";
        }
        ?>
    </tbody>
</table>
<script>
    // function next(){
    //     alert("sss");
    //     <meta http-equiv='Refresh' content='0;URL=index.php'/>
    // }
</script>
<form method="get" action="1.php" >
    <!--button type="submit"><u>下一页</u></!--button-->
    <input type="text" placeholder="想要跳转的页数" name="page" />
    <input type="submit" value="跳转"  /><!--style="margin:0 0 0 10px;"-->
</form>