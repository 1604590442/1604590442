function mOver(obj){
    obj.style.color = "aquamarine"
    var a = 1;
    a = Math.floor(Math.random() * 12) + 1;
	switch (a) {
        case 1:
            obj.innerHTML="&#xe606;"
            break;
    
        case 2:
            obj.innerHTML="&#xe607;"
            break;
    
        case 3:
            obj.innerHTML="&#xe608;"
            break;
    
        case 4:
            obj.innerHTML="&#xe60a;"
            break;
    
        case 5:
            obj.innerHTML="&#xe60c;"
            break;
    
        case 6:
            obj.innerHTML="&#xe60e;"
            break;
    
        case 7:
            obj.innerHTML="&#xe60f;"
            break;
    
        case 8:
            obj.innerHTML="&#xe610;"
            break;
    
        case 9:
            obj.innerHTML="&#xe611;"
            break;
    
        case 10:
            obj.innerHTML="&#xe612;"
            break;
    
        case 11:
            obj.innerHTML="&#xe613;"
            break;

        default: obj.innerHTML="&#xe614;"
            break;
    }
}

function mOut(obj){
    obj.style.color = "white"
	obj.innerHTML="登录"
}