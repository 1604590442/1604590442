<html lang="zh-CN" style="height: auto;">
<head>
    <meta charset="utf-8">
    <script src="./Vue/vue.js"></script>
    <link rel="stylesheet" href="./css/adminlte.min.css">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1.0/dist/css/adminlte.min.css"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.13.0/css/all.min.css">
    <link rel="icon" href="./../favicon.ico">
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-136793183-1');
    </script>
    <title>index</title>
    <link type="text/javascript" href="https://cdn.jsdelivr.net/npm/react-dom@17.0.1/umd/react-dom.production.min.js">
    <link rel="stylesheet" href="./CSS/index.css">
</head>

<body class="layout-top-nav" style="height: auto;">
    <div class="hp-wrapper">
        <div id="fixed-bg">
            <div id="fixed-bg" :style="bgc">
            </div>
        </div>
        <!-- <?php var_dump(scandir("."));?> -->
        <nav class="navbar navbar-expand fixed-top navbar-cyan navbar-dark ml-0">
            <div class="container">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand">菜鸟积</a>
                </div>

                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#">资源库</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link" data-toggle="dropdown" href="#">
                                <i class="fas fa-language" aria-hidden="true"></i>
                                <span class="d-none d-sm-inline">列表</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                                <a href="https://littleskin.cn?lang=zh_CN" target="_blank" class="dropdown-item locale">
                                    我的世界
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item locale">
                                    视频
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="https://littleskin.cn?lang=en" class="dropdown-item locale">
                                    音乐
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item locale">
                                    小说
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item locale">
                                    漫画
                                </a>
                                <div class="dropdown-divider"></div>
                            </div>
                        </li>


                        <!-- <li class="nav-item dropdown user-menu">
                            <a href="#" class="nav-link d-flex align-items-center" data-toggle="dropdown">
                                登录
                            </a>
                        </li> -->

                        <li class="nav-item">
                            <a class="nav-link" href="./php/login.php">
                                <i class="icon fas fa-sign-in-alt"></i>
                                登录
                            </a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="splash">
                <h1 class="splash-head">菜鸟积</h1>
                <p class="splash-subhead">
                    快速、可靠的公益资源分享站
                </p>
                <p>
                    <a href="#" class="main-button">
                        用户中心
                    </a>
                </p>
            </div>
        </div>

    </div>
    <div id="intro">
        <div class="container">
            <div class="text-center">
                <h1><strong>菜鸟积</strong> 好处都有啥？</h1>
                <br>
                <br>
                <div class="container-lg">
                    <div class="row">
                        <div class="col-lg">
                            <i class="fas fa-check mb-3" aria-hidden="true"></i>
                            <h3>免配置</h3>
                            <p>无需任何繁琐的配置<br>现已加入肯德基豪华套餐</p>
                        </div>
                        <div class="col-lg">
                            <i class="fas fa-bolt mb-3" aria-hidden="true"></i>
                            <h3>积速加载</h3>
                            <p>由菜积鸡分发资源<br><del>跑得比邓超星还快</del></p>
                        </div>
                        <div class="col-lg">
                            <i class="fas fa-dollar-sign mb-3" aria-hidden="true"></i>
                            <h3>公益免费</h3>
                            <p>建站起即采用公益运营模式<br>基础服务永不收费</p>
                        </div>
                    </div>
                </div>
            </div>
            <br>
        </div>
    </div>
    <div id="footer-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-2">
                    菜鸟积 基于定制的 肯德基豪华套餐，提供 各种资源的上传和托管 以及第三方 积鸡 账户登录鉴权服务。现在，我们或许是仅次于 逆流星空 的积内第二大 资源分享网站。
                </div>
                <div class="col-lg-4"></div>
                <div class="col-lg-2 d-flex justify-content-center align-items-center">
                    <a href="#" class="main-button">
                        开始使用
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright" class="with-intro">
        <div class="container">

            <!-- YOU CAN NOT MODIFIY THE COPYRIGHT TEXT W/O PERMISSION -->
            <div id="copyright-text" class="float-right d-none d-sm-inline">
                由 <a href="https://github.com/bs-community/blessing-skin-server">Dark Charger Xing</a> 强力驱动。
            </div>
            <strong>© 2022 - 2022 <a href="https://mcskin.littleservice.cn">菜鸟积</a></strong> | <a href="https://beian.miit.gov.cn" target="_blank" rel="noopener noreferrer">📕 DDD 备 114514 号 - 1</a>

        </div>
    </div>

    <script type="application/json" id="blessing-extra">
        {
            "transparent_navbar": true
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@blessing-skin/admin-lte@3.1.1/dist/admin-lte.min.js" integrity="sha256-RXsx1d8m0chfHsuuOui/cS8BohuAfDa9/aG2NgkdcGc=" crossorigin="anonymous"></script>
    <div></div>


    <script>
        Vue.config.productionTip = false

        const vm = new Vue({
            el: '#fixed-bg',
            data: {
                // bgc: "https://littleskin-resource-1307271577.file.myqcloud.com/bingpic/2022/3/31.jpg"
                bgc: {
                    backgroundImage: "url(" + "./img/"+ Math.floor(Math.random()*47) +".jpg" + ")"
                }
            },
        })
    </script>
</body>

</html>