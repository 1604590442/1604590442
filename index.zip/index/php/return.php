<?php 
    setcookie("log","",time()-3600);
    setcookie("login","",time()-3600);
    header('Location:../index.php');
?>