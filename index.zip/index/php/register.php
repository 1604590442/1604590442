<?php
    include ("./../inc/connect.php");//youwenti
    include("./../inc/function.php");
    //mysqli_query($link,"update users set pwd = 123 where id = 3;");//写到这里可以
    session_start();
    $name = $_POST['user'];
    $pwd = $_POST['pwd'];
    $vcode = $_POST['vcode'];
    $name =trim($name);
    $pwd = trim($pwd);
    $vcode = strtolower(trim($vcode));
    $ses = session_id();
    $sevocode = $_SESSION['vcode'];
    session_unset();
    session_destroy();
    if($vcode!=$sevocode)
    {
        //header("location:index.php?id=1");
        echo "<script>alert('验证码错误');location.replace(document.referrer);</script>";
    }
    else
    {
        $link = mysqli_connect($hostname, $username, $password, $database, $port);
        if (!$link) {
            echo "<script>alert('连接数据库失败');location.replace(document.referrer);</script>";
            //location.replace(document.referrer);返回页面并且刷新
        }
        if (isset($_POST['user']) && isset($_POST['pwd'])) {
            if (isexist($name) == 1) {
                echo "<script>alert('账号已存在');location.replace(document.referrer);</script>";
            } else {
                $sql = "insert into admin(name,pwd) values(?,?)";
                @$pre_sql = $link->prepare($sql);
                @$pre_sql->bind_param("ss", $name, $pwd);
                if ($pre_sql->execute()) {
                    echo "<script>alert('注册成功');history.back();</script>";
                }
            }
    }
    
    }
