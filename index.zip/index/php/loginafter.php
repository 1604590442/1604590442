<?php
    include "../inc/connect.php";
    include "../inc/function.php";
    session_start();
    $name = $_POST['name'];
    $pwd = $_POST['pwd'];
    $vcode = $_POST['vcode'];
    $name =trim($name);
    $pwd = trim($pwd);
    $vcode =strtolower(trim($vcode));
    $ses_id = session_id();
    $sevocode = $_SESSION['vcode'];
    $value=base64_encode("$name"."$pwd"."$ses_id");
    setcookie("log",$value,time()+3600);
    session_unset();
    session_destroy();
    if($vcode!=$sevocode)
    {
        //header("location:index.php?id=1");
        echo "<script>alert('验证码错误');location.replace(document.referrer);</script>";
    }
    else
    {
        // $con=mysqli_connect("localhost",$username,$password,$database,$port);
        // $sql ="select name,pwd from admin where name=? and pwd=?";
        // $pre_sql = $con->prepare($sql);
        // $pre_sql->bind_param("ss",$name,$pwd);
        // if($pre_sql->execute())
        // {
        //     $pre_sql->store_result();
        //     if($pre_sql->num_rows()==1)//登录成功
        //     {
        //         mysqli_close($con);
        //         setcookie("pass","$name$ses");
        //         header('Location:admin.php');
        //     }
        //     else
        //     {
        //         mysqli_close($con);
        //         //header("location:index.php?id=2");
        //         echo "<script>alert('密码或账号错误');location.replace(document.referrer);</script>";
        //     }
        // }
        if(login($name,$pwd))
        {
            setcookie("login",$value,time()+3600);
            header('Location:admin.php');
        }
        else
        {
            echo "<script>alert('密码或账号错误');location.replace(document.referrer);</script>";
        }
    }
    //echo $name;
    //echo $pwd;
    
    //@$result=mysqli_query($con,$sql);
    //$arr= mysqli_fetch_all($result);
    //var_dump($arr);
   // $login = base64_encode("yes");
    //var_dump($_COOKIE);
    // if($vcode == $_COOKIE['vcode'])
    // {
    //     header("Location:index.php?value=asd");
    // }
    // if($arr != null)
    // {
    //     setcookie("co1","123");
    //     header('Location:admin.php');
    // }
    // else{
    //     setcookie("co1","",time()-100);
    //     header("Location:index.php?value=".$rep);
    // }
?>