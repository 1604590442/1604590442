<!DOCTYPE html>
<html>

<head>
    <title>123</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/Picture.css">
    <link rel="stylesheet" href="../css/iconfont/iconfont.css">
    <script src="../js/onclick_js.js"></script>
    <style>
        .form-group input {
            display: inline-block;
            width: 350px;
            height: calc(2.25rem + 2px);
            padding: .375rem .75rem;
            font-size: 16px;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: .25rem;
            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out
        }

        .form-group input:focus {
            color: #495057;
            background-color: #fff;
            border-color: #80f0ff;
            outline: 0;
            box-shadow: 0 0 0 .2rem rgb(33, 162, 179)
        }

        .ZC {
            position: absolute;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
    </style>
</head>

<body>
    <div class="stars"></div>
    <div class="ZC" style="text-align:center">
        <h2 style="color:rgb(163, 206, 241); text-align:center">测试注册界面<br /></h2>
        <div class="registe1">
            <form method="POST" action="./register.php">
                <div class="form-group">
                    <input type="text" id="exampleInputEmail1" maxlength="16" name="user" aria-describedby="emailHelp" placeholder="请输入用户名">
                </div>

                <div class="form-group">
                    <input type="password" id="exampleInputPassword1" maxlength="16" name="pwd" placeholder="请输入密码">
                </div>

                <div id="YZM" class="form-group">
                    <input type="text" id="exampleInputYZM" name="vcode" maxlength="6" style="height:40px;width:265px" placeholder="请输入验证码">
                    <img id="alt" style="cursor: pointer;" onclick="reAlt()" title="点击更换验证码" src="../inc/yanzhengma.php">
                </div>
                <input type="submit" value="注册" style="width:70px;height:40px; margin: top 20px;"><br>
            </form>
            <a href="./../index.php">返回首页</a>
        </div>
        <br>

    </div>

    <script src="../js/jquery-3.3.1.slim.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.min.js"></script>

    <script>
        $(document).ready(function () {
            var stars = 800;
            var $stars = $(".stars");
            var r = 800;
            for (var i = 0; i < stars; i++) {
                var $star = $("<div/>").addClass("star");
                $stars.append($star);
            }
            $(".star").each(function () {
                var cur = $(this);
                var s = 0.1 + (Math.random() * 1);
                var curR = r + (Math.random() * 300);
                cur.css({
                    transformOrigin: "0 0 " + curR + "px",
                    transform: " translate3d(0,0,-" + curR + "px) rotateY(" + (Math.random() *
                            360) + "deg) rotateX(" + (Math.random() * -50) + "deg) scale(" + s +
                        "," + s + ")"

                })
            })
        })
    </script>

</body>

</html>