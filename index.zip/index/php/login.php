<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="./../CSS/Grid_style.css">
    <link rel="stylesheet" href="./../CSS/bootstrap.min.css">
    <link rel="stylesheet" href="./../CSS/Picture.css">
    <link rel="stylesheet" href="./../CSS/iconfont/iconfont.css">
    <script src="./../JS/onclick_js.js"></script>
    <script src="./../JS/Picture.js"></script>
    <script src="./../JS/mouse.js"></script>
    <title>登陆</title>
</head>

<body>
    <main class="main" role="main">

        <div class="stars">
            <!-- <img src="./../img/-72516b97d7730476.jpg" alt="">
            <img src="./../img/702fb890d725012a.jpg" alt="">
            <img src="./../img/QQ图片20210306195342.jpg" alt=""> -->
        </div>

        <div class="container">
            <div class="row">
                <div class="offset-md-3 col-md-6">

                    <form class="form-container" action="./loginafter.php" method="POST">
                        <h2 style="color: aquamarine;">登陆</h2>

                        <div class="form-group">
                            <label for="exampleInputEmail1" style="color: aquamarine;">用户名</label>
                            <input type="text" maxlength="16" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="请输入用户名" >
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1" style="color: aquamarine;">密码</label>
                            <input type="password" maxlength="16" class="form-control"name="pwd" id="exampleInputPassword1" placeholder="请输入密码">
                        </div>

                        <div id="YZM" class="form-group">
                            <input type="text" class="form-check-YZM" id="exampleInputYZM" name="vcode" placeholder="请输入验证码">
                            <img id="alt" style="cursor: pointer;"maxlength="6" onclick="reAlt()" title="点击更换验证码" src="./../inc/yanzhengma.php">
                        </div>

                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1" style="color: aquamarine;">记住信息</label>
                        </div>

                        <button type="submit" class="btn btn-success btn-block DL">
                            <span class="iconfont" onmouseover="mOver(this)" onmouseout="mOut(this)">登录</span>
                        </button>

                        没有账号？<a href="./registe.php">注册</a>一个
                        <!-- 没有账号？注册一个<button onclick='window.open("./../PHP/ZHUCE.html")' type="button" class="btn btn-success btn-block" style="height:35px;width:200px">注册</button> -->
                    </form>

                </div>
            </div>
        </div>
    </main>

    <div class="footer">
        <div class="container">
            登录页面 @2022年3月32日
        </div>
    </div>


    <script src="./../JS/jquery-3.3.1.slim.min.js"></script>
    <script src="./../JS/popper.min.js"></script>
    <script src="./../JS/bootstrap.min.js"></script>
    <script src="./../JS/jquery.min.js"></script>


    <script>
        $(document).ready(function() {
            var stars = 800;
            var $stars = $(".stars");
            var r = 800;
            for (var i = 0; i < stars; i++) {
                var $star = $("<div/>").addClass("star");
                $stars.append($star);
            }
            $(".star").each(function() {
                var cur = $(this);
                var s = 0.1 + (Math.random() * 1);
                var curR = r + (Math.random() * 300);
                cur.css({
                    transformOrigin: "0 0 " + curR + "px",
                    transform: " translate3d(0,0,-" + curR + "px) rotateY(" + (Math.random() * 360) + "deg) rotateX(" + (Math.random() * -50) + "deg) scale(" + s + "," + s + ")"

                })
            })
        })
    </script>
</body>

</html>