<!DOCTYPE html>
<html>
<head>
    <title>管理系统</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../CSS/admin.css" type="text/css" />
    <!--引入css-->
</head>
<?php
    if($_COOKIE['log']!=$_COOKIE['login']||!$_COOKIE['log'])
    {
        echo "<script>alert('请登录');history.back();</script>";
    }
?>
<script>
    function Exit() {
        alert("已退出");
    }
</script>
<!-- <?php 
    //setcookie("log","",time()-3600);
    //setcookie("login","",time()-3600);
?> -->
<body>
    <a href="./return.php" onclick="Exit()" style="display: block;float: right;">退出</a>
    <br><br>
    <div class="left1">
        <table>
            <tbody>
                <tr>
                    <td id="memu1" style="display: flexbox; cursor: pointer;
                    height: 10px; ;width: 5%;
                    background-color: rosybrown;
                    text-align: center;" onclick="Change()">
                        <p style="color: blue;">1</p>
                    </td>
                </tr>
                <tr>
                    <!-- <img style="cursor: pointer;" id="Alt" title="点击更换图片" onclick="Alt()" src="../../test.php"> -->
                    <td style="display: flexbox;cursor: pointer;height: 3%; ;width: 5%; background-color: rosybrown;text-align: center;">
                        <p style="color: blue;">1</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="right1">

    </div>
</body>

</html>