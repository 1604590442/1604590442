function reAlt() {
    //alert("更换成功");
    var alt = document.getElementById("alt");
    var a = Math.random(0, 1) * 1000;
    a = Math.floor(a);
    var nowin = window.location.href;
    alt.src = `./../inc/yanzhengma.php?id=${a}`;
}