<?php
include_once("function.php");
session_start();
$_SESSION['vcode']=strtolower(vcodex());
?>