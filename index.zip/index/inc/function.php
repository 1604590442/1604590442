<?php
function vcodex(){
	
	$string = "ABCDEFGHJKMNPQRSTUVWXY3456789";
    	$str = "";
    	for($i=0;$i<4;$i++){
        	$pos = $string[rand(0,28)];
        	$str .= $pos;
    	}
    //session_start();
    //$_SESSION['img_number'] = $str;
	
	$img_handle = Imagecreate(80, 28);  //图片大小80X20
    	$back_color = ImageColorAllocate($img_handle, 255, 255, 255); //背景颜色（白色）
    	$txt_color = ImageColorAllocate($img_handle, 0,0, 0);  //文本颜色（黑色）
    
    //加入干扰线
    	// for($i=0;$i<3;$i++)
    	// {
        // 	$line = ImageColorAllocate($img_handle,rand(0,255),rand(0,255),rand(0,255));
        // 	Imageline($img_handle, rand(0,15), rand(0,15), rand(100,150),rand(10,50), $line);
    	// }
    //加入干扰象素
    	for($i=0;$i<200;$i++) 
    	{
        	$randcolor = ImageColorallocate($img_handle,rand(0,255),rand(0,255),rand(0,255));
        	Imagesetpixel($img_handle, rand()%100 , rand()%50 , $randcolor);
    	}
	
	Imagefill($img_handle, 0, 0, $back_color);             //填充图片背景色
    	ImageString($img_handle, 30, 20, 5, $str, $txt_color);//水平填充一行字符串
	ob_clean();   // ob_clean()清空输出缓存区    
    	header("Content-type: image/png"); //生成验证码图片    
    	Imagepng($img_handle);//显示图片
	return $str;
	
}
function login($name,$pwd)
{
	// include_once(__DIR__."/connect.php");
	$hostname="localhost";
    $username="root";
    $password="root";
    $database="user";
    $port="3306";
	$con=mysqli_connect($hostname,$username,$password,$database,$port);
	$sql ="select name,pwd from admin where name=? and pwd=?";
	$pre_sql = $con->prepare($sql);
	$pre_sql->bind_param("ss",$name,$pwd);
	if($pre_sql->execute())
	{
		$pre_sql->store_result();
		if($pre_sql->num_rows()==1)//有这个数据
		{
			mysqli_close($con);
			return 1;
		}
		else
		{
			mysqli_close($con);
			return 0;
		}
	}
}
function isexist($name)
{
	$hostname="localhost";
    $username="root";
    $password="root";
    $database="user";
    $port="3306";
	//include_once(__DIR__."/connect.php");
	$con=mysqli_connect($hostname,$username,$password,$database,$port);
	$sql ="select name from admin where name=?";
	$pre_sql = $con->prepare($sql);
	$pre_sql->bind_param("s",$name);
	if($pre_sql->execute())
	{
		$pre_sql->store_result();
		if($pre_sql->num_rows()==1)//有这个数据
		{
			mysqli_close($con);
			return 1;
		}
		else
		{
			mysqli_close($con);
			return 0;
		}
	}
}
?>